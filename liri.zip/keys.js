// Twitter and Spotify keys

// Twitter API Key

console.log('this is loaded');

var twitterKeys = {
  consumer_key: 's0SbSohUYxpnve6h2zxR9cRav',
  consumer_secret: '6ozHOVvMKGu5tXUuxlE0goeovPjLhu5dMSAbi4XyZqUo2TJIz8',
  access_token_key: '912383265859915776-suOfUczBXndiuRXFGGTw4aMnYE8MWa1',
  access_token_secret: 'yi3eH5Ly56nsjErkVv1vnZqIHojGabk3JXPkKqxLLRJE5'
};

//console.log(twitterKeys);

module.exports = twitterKeys;

// Spotify API Key
 
var spotifyKeys = {
  id: '8af97ebdd9d64f9f8b52ae7558fbb8e9',
  secret: '29f85e3924804d58958b8fc759eeb367'
};

//console.log(spotifyKeys);

module.exports = spotifyKeys;
			
 
